ServerEvents.recipes(event => {
    
    event.remove({ output: 'minecraft:flint', type: 'create:milling' })
    
    event.custom({
        type: "create:milling",
        ingredients: [
        { "item": "minecraft:gravel" }
        ],
        "processing_time": 250,
        results: [
        { "id": "minecraft:flint" },
        { "id": "minecraft:iron_nugget", chance: 0.10 },
        { "id": "minecraft:sand" }
        ]

    })
})