ServerEvents.recipes(event => {
    
    event.remove({ output: 'minecraft:breeze_rod', type: 'create:filling' })
    
    event.custom({
        type: "create:filling",
        ingredients: [
            {"item": "minecraft:snowball"},
            { type: "fluid_stack", fluid: "minecraft:water", amount: 1000 }
        ],
        results: [
        { "id": "minecraft:blue_ice" },
        ]

    })
})