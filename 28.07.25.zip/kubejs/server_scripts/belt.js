ServerEvents.recipes(event => {
event.custom({
        type: "create:crushing",
        ingredients: [
        { "item": "minecraft:oak_sapling" }
        ],
        "processing_time": 250,
        results: [
        { "id": "minecraft:kelp" },
        ]

    })
})