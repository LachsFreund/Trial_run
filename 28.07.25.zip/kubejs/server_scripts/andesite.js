ServerEvents.recipes(event => {
    event.shapeless(
  Item.of('minecraft:andesite', 2), // arg 1: output
  [
    'minecraft:gravel',
    'create:limestone'	       // arg 2: the array of inputs
  ]
)
})