ServerEvents.recipes(event => {
    event.custom({
        type: "create:mixing",
        "heat_requirement": "heated",
        ingredients: [
        { "item": "minecraft:copper_ingot" },
        { "item": "create:andesite_alloy" }
        ],
        results: [
        { "id": "create:brass_ingot", count: 2 },
        ]

    })
})
