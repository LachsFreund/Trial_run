StartupEvents.registry('item', event => {
    event.create("molten_deepslate") .tooltip('A hot clump of deepslate');
})