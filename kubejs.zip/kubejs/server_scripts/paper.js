ServerEvents.recipes(event => {
    event.custom({
        type: "create:pressing",
        ingredients: [
        { item: "minecraft:oak_leaves" },
       ],
        results: [
        { "id": "minecraft:paper", count: 1 },
        ]

    })

    event.custom({
        type: "create:pressing",
        ingredients: [
        { item: "minecraft:oak_sapling" },
       ],
        results: [
        { "id": "minecraft:paper", count: 1 },
        ]

    })
})