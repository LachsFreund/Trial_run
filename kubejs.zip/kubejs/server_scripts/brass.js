ServerEvents.recipes(event => {
    event.custom({
        type: "create:mixing",
        "heat_requirement": "heated",
        ingredients: [
        { "item": "minecraft:copper_ingot" },
        { "item": "create:andesite_alloy" }
        ],
        results: [
        { "id": "create:brass_ingot", count: 2 },
        ]

    })
})

ServerEvents.recipes(event => {
    
    event.remove({ output: 'minecraft:breeze_rod', type: 'create:filling' })
    
    event.custom({
        type: "create:filling",
        ingredients: [
            {"item": "minecraft:snowball"},
            { type: "fluid_stack", fluid: "minecraft:water", amount: 1000 }
        ],
        results: [
        { "id": "minecraft:blue_ice" },
        ]

    })
})