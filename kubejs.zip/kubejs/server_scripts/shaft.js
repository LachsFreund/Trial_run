ServerEvents.recipes(event => {
    event.shaped(
    {
  "type": "minecraft:crafting_shaped",
  "category": "misc",
  "key": {
    "A": { "item": "minecraft:iron_ingot" }
    },
        "pattern": [
        "A",
        "A"
    ],
    "result": 
    { "count": 4, "id": "create:shaft" }
    })
})