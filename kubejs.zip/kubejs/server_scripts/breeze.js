ServerEvents.recipes(event => {
    
    event.remove({ output: 'minecraft:breeze_rod', type: 'create:filling' })
    
    event.custom({
        type: "create:filling",
        ingredients: [
        { "item": "minecraft:stick" },
        { type: "fluid_stack", fluid: "trialanderror:ominous_bile", amount: 10 }
        ],
        results: [
        { "id": "minecraft:breeze_rod" },
        ]

    })
})