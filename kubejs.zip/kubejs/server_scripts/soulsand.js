ServerEvents.recipes(event => {
    event.shaped(
    Item.of("minecraft:soul_sand", 1),
    [
        'ABA',
        'BCB',
        'ABA',
    ],
    {
        A: 'minecraft:bone',
        B: 'minecraft:cobblestone',
        C: 'minecraft:sand',
    }
    )
})