ServerEvents.recipes(event => {
    event.shaped(
    Item.of("create:item_drain", 1),
    [
        '   ',
        'ABA',
        'AAA',
    ],
    {
        A: 'minecraft:copper_ingot',
        B: 'minecraft:copper_trapdoor'
    }
    )
})