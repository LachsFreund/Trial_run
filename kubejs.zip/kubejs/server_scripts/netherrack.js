ServerEvents.recipes(event => {
  event.shaped({
    type: "minecraft:crafting_shaped",
    "category": "misc", 
    "key": { 
        "A": { item: "minecraft:deepslate" },
        "B": { item: "minecraft:lava_bucket" }
        },
        pattern: [
        "AAA",
        "ABA",
        "AAA"
        ],
        result: 
        { id: "minecraft:netherrack", count: 8 }
    })
})