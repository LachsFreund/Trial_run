ServerEvents.recipes(event => {
    event.shaped(
    Item.of("create:belt_connector", 1),
    [
        'AAA',
        'AAA',
    ],
    {
        A: 'minecraft:oak_leaves',
    }
    )
})