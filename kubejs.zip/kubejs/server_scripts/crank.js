ServerEvents.recipes(event => {
    event.shaped(
    Item.of("create:hand_crank", 1),
    [
        '   ',
        'AAA',
        '  B',
    ],
    {
        A: 'minecraft:oak_planks',
        B: 'minecraft:iron_ingot'
    }
    )
})