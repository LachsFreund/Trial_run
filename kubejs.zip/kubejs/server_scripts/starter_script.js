PlayerEvents.loggedIn(event => {
  const player = event.player;
  const persistentData = player.persistentData;

  if (!persistentData.hasGivenLava) {
    // Nur beim ersten Login
    persistentData.hasGivenLava = true;

    player.give('minecraft:lava_bucket');
    event.server.runCommandSilent(`tellraw @a {"text":"Viel Spaß, $player.name! führe /challengeinfo zum starten aus.","color":"gold"}`);
  }
});
