ServerEvents.recipes(event => {
event.shaped(
  Item.of('create:millstone', 1), // arg 1: output
  [
    ' A ',
    ' B ', // arg 2: the shape (array of strings)
    ' C '
  ],
  {
    A: 'create:cogwheel',
    B: 'minecraft:oak_log',  //arg 3: the mapping object
    C: 'minecraft:tuff_bricks'
  }
)
})