ServerEvents.recipes(event => {
    event.custom({
        type: "create:compacting",
        ingredients: [
        { "item": "minecraft:cobblestone" }
        ],
        results: [
        { "id": "minecraft:lava", amount: 25 },
        ]

    })
})