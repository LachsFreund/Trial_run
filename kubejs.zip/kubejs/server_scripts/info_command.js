ServerEvents.basicCommand('challengeinfo', event => {
  if (!event.player) return; // Nur im Spiel ausführbar

  event.player.tell('Info zur Challenge:');
  event.player.tell('Crafte dir einen Honig Eimer.');
  event.player.tell('Du brauchst einen Limestone Generator,');
  event.player.tell('einen Cobble Generator und einen');
  event.player.tell('Millstone zum Starten. Du musst dich in');
  event.player.tell('Trial Chamber umschauen. Es gibt alles was du brauchst.');
  event.player.tell(' ');
  event.player.tell('Verzweifle nicht und viel Spaß! (Es gibt immer einen Weg)');
});
