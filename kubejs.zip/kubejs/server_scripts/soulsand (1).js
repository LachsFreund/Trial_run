ServerEvents.recipes(event => {
    event.shaped(
    Item.of("minecraft:paper", 1),
    [
        'AAA', 
    ],
    {
        A: 'minecraft:oak_leaves', 
    }
    )
})


