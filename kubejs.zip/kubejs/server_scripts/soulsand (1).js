ServerEvents.recipes(event => {
    event.shaped(
    Item.of("minecraft:soul_sand", 1),
    [
        'AAA', 
    ],
    {
        A: 'minecraft:oak_leaves', 
    }
    )
})

