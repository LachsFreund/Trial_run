ServerEvents.recipes(event => {
    event.shaped(
    Item.of("trialanderror:common_tabula_rasa", 1 ),
    [
        'BAB',
        'BCB',
        'BBB',
    ],
    {
        A: 'create:polished_cut_limestone',
        B: 'create:cut_limestone',
        C: 'minecraft:copper_block',
    }
    )
})

ServerEvents.recipes(event => {
    event.shaped(
    Item.of("trialanderror:common_tabula_rasa", 2 ),
    [
        'BAB',
        'BCB',
        'BBB',
    ],
    {
        A: 'trialanderror:common_tabula_rasa',
        B: 'create:cut_limestone',
        C: 'minecraft:copper_block',
    }
    )
})

ServerEvents.recipes(event => {
    event.shaped(
    Item.of("trialanderror:tabula_rasa", 1 ),
    [
        'BAB',
        'BCB',
        'BBB',
    ],
    {
        A: 'create:polished_cut_limestone',
        B: 'create:cut_limestone',
        C: 'minecraft:diamond',
    }
    )
})

ServerEvents.recipes(event => {
    event.shaped(
    Item.of("trialanderror:tabula_rasa", 2 ),
    [
        'BAB',
        'BCB',
        'BBB',
    ],
    {
        A: 'trialanderror:tabula_rasa',
        B: 'create:cut_limestone',
        C: 'minecraft:diamond',
    }
    )
})