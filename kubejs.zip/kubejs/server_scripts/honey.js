ServerEvents.recipes(event => {
    event.shapeless(
        Item.of('minecraft:honey_bottle', 4),
        [
        'minecraft:honeycomb',
        ]
    )
})

ServerEvents.recipes(event => {
    event.shaped(
    Item.of("create:honey_bucket", 1),
    [
        'AAA',
        'AAA',
        'AAA',
    ],
    {
        A: 'minecraft:honey_bottle',
    }
    )
})