ServerEvents.recipes(event => {
    event.shapeless(
        Item.of('minecraft:honey_bottle', 1 ),
        [
        'minecraft:honeycomb',
        ]
    )
})

ServerEvents.recipes(event => {
    event.shaped(
    Item.of("create:honey_bucket", 1),
    [
        'A',
        'B',
    ],
    {
        A: 'minecraft:honey_block',
        B: 'minecraft:bucket',
    }
    )
})