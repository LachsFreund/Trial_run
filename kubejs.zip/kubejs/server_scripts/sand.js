ServerEvents.recipes(event => {
    
    event.remove({ output: 'minecraft:flint', type: 'create:milling' })
    
    event.custom({
        type: "create:milling",
        ingredients: [
        { "item": "create:limestone" }
        ],
        "processing_time": 250,
        results: [
        { "id": "minecraft:flint" },
        { "id": "create:copper_nugget", chance: 0.20 },
        { "id": "minecraft:quartz", chance: 0.25 }
        ]

    })
})